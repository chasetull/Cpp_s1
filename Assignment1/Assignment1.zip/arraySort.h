// Header file for assignment 1

int addToArrayAsc(float sortedArray[], int numElements, float newValue);